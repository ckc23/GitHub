package org.owasp.webgoat.plugins;

import org.owasp.webgoat.lessons.SequentialLessonAdapter;

public class TestPlugin extends SequentialLessonAdapter {
}
